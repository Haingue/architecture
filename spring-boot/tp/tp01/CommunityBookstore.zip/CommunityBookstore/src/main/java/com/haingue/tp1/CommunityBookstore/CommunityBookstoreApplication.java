package com.haingue.tp1.CommunityBookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommunityBookstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommunityBookstoreApplication.class, args);
	}

}
