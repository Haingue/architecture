package com.haingue.tp1.CommunityBookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommunityBookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
