package com.imt.services.joboffer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobOfferServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobOfferServiceApplication.class, args);
	}

}
