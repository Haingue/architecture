package com.imt.services.joboffer.dto;

public record CompanyDto (
        String name,
        String address
) {
}
